### Hexlet tests and linter status:
[![Actions Status](https://github.com/145kjhgv/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/145kjhgv/python-project-49/actions)

# Maintainability Badge from codeclimate
[![Maintainability](https://api.codeclimate.com/v1/badges/2c99a9ba728fe3c0d7e0/maintainability)](https://codeclimate.com/github/145kjhgv/python-project-49/maintainability)

https://asciinema.org/a/GnrJvEgNwclVqgopVtCqcbPC3

https://asciinema.org/a/OXjKvYTfXZpS1uzFzi8XnzEGW

https://asciinema.org/a/VpC6AG81KbabDTWKL6R5sxC91

https://asciinema.org/a/H1EdgglfDbirfMpZcSbQH6p75

